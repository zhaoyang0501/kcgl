$.common = {
		contextPath : null,
		setContextPath : function(path){
			contextPath = path;
		},
		getContextPath : function(){
			return contextPath;
		}
};
 