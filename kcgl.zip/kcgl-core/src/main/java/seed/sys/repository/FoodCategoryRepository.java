package seed.sys.repository;
import seed.common.repository.SimpleCurdRepository;
import seed.sys.entity.FoodCategory;
public interface FoodCategoryRepository   extends SimpleCurdRepository<FoodCategory ,Long>{
}
