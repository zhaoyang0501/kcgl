package seed.sys.repository;
import seed.common.repository.SimpleCurdRepository;
import seed.sys.entity.Good;
public interface GoodRepository   extends SimpleCurdRepository<Good ,Long>{
	
}
