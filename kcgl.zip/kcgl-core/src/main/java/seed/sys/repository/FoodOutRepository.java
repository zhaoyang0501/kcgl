package seed.sys.repository;
import seed.common.repository.SimpleCurdRepository;
import seed.sys.entity.FoodOut;
public interface FoodOutRepository   extends SimpleCurdRepository<FoodOut ,Long>{
}
