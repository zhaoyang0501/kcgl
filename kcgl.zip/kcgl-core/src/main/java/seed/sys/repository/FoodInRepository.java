package seed.sys.repository;
import seed.common.repository.SimpleCurdRepository;
import seed.sys.entity.FoodIn;
public interface FoodInRepository   extends SimpleCurdRepository<FoodIn ,Long>{
}
