package seed.core.repository;
import seed.common.repository.SimpleCurdRepository;
import seed.core.entity.Role;
public interface RoleRepository   extends SimpleCurdRepository<Role ,Long>{
}
